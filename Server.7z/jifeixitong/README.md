To deploy the backend system.

You need to:

* Use JDK 11
* Use MySql 8.X  and run the sql.sql file in the current directory to create the database
* Use Maven to settle the environment
* And ...



You have to find the application.yml file. It is in the directory shown below.

![image-20240202223405828](assets/image-20240202223405828.png)

Open it and change the following settings:

![image-20240202223536214](assets/image-20240202223536214.png)

