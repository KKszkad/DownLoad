package com.whut.jifeixitong;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JifeixitongApplicationTests {

	@Test
	void contextLoads() {
	}

}
