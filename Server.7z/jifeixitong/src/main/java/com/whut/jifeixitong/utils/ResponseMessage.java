package com.whut.jifeixitong.utils;

/**
 * 后端返回给前端的响应消息
 */
public interface ResponseMessage {
    String SUCCESS_MSG = "ok";
    String FAIL_MSG = "fail";

}
