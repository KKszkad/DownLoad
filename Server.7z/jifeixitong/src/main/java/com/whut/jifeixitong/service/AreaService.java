package com.whut.jifeixitong.service;

import com.whut.jifeixitong.entities.Area;

import java.util.List;

public interface AreaService {
    List<Area> get_Area();
}
