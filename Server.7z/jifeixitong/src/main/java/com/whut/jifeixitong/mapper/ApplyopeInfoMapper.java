package com.whut.jifeixitong.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.whut.jifeixitong.entities.TugApplyInfo;

public interface ApplyopeInfoMapper extends BaseMapper<TugApplyInfo> {
}
